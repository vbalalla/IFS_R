<?php
<!--##session report_html_function##-->
<!--##
	if (bPrinterFriendly) {
##-->

	// Export to HTML
	function ExportHtml($html) {
		//global $gsExportFile;
		//header('Content-Type: text/html' . (EWR_CHARSET <> '' ? ';charset=' . EWR_CHARSET : ''));
		//header('Content-Disposition: attachment; filename=' . $gsExportFile . '.html');
		//echo $html;
	} 

<!--##
	};
##-->
<!--##/session##-->
?>