<!--##session userjs##-->
// Global user functions
<!--##~SYSTEMFUNCTIONS.GetClientScript("Global","Global Code")##-->
<!--##/session##-->